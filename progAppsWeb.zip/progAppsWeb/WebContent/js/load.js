function loadParts() { 
	let htmlContentToAppend = `
    <nav class='navbar navbar-expand-lg navbar-light rosadito_back shw-sm'> <a class='navbar-brand ml-2' href='./index.jsp'>
        <strong>edEXT</strong> </a> <button class='navbar-toggler' type='button' data-toggle='collapse'
        data-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false'
        aria-label='Toggle navigation'> <span class='navbar-toggler-icon'> </span> </button>
    <div class='collapse navbar-collapse' id='navbarSupportedContent'>
        <ul class='navbar-nav mr-5'>

            <li class='nav-item dropdown'> <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown'
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Cursos</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown' > 
					 
                    <div class='' id="alcur"></div>

                    
					<a class='dropdown-item' href='./listaCurso.jsp'>Lista
                        Cursos</a>
                   
                
                    <div class='dropdown-divider'></div>
                
				    <a class='dropdown-item' href='./listaCurso.jsp'>Consulta Cursos</a>
                    

                </div>
            </li>
            <li class='nav-item dropdown'> <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown2'
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Ediciones</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown2'>
                    <a class='dropdown-item' href='./altaEdicion.jsp'>Alta Edición</a>
                    <div class='dropdown-divider'></div>
                    <a class='dropdown-item' href='./consultaEdicion.jsp'>Consultar Ediciones</a>
                    <div class='dropdown-divider'></div>

                    <div class='' id="aled"></div>
                    
                    <div class='' id="insced"></div>
				    
                    <div class='' id="listaResultadosInscripciones"></div>

					<div class='' id="listaAcep"></div>
                </div>
            </li>
            
			<li class='nav-item dropdown'>
                <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown11' role='button' data-toggle='dropdown'
                    aria-haspopup='true' aria-expanded='false'>Formaciones</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown11'>
                    <div class='' id="esfor"> </div>
    
                
                    <div class='' id="alfor"> </div>
                    
                </div>
            </li>
           
            <li class='nav-item dropdown'>
                <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown1' role='button' data-toggle='dropdown'
                    aria-haspopup='true' aria-expanded='false'>Usuarios</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown1'>
                    <a class='dropdown-item' href='./listaUsuarios.jsp'>Lista Usuarios</a>
                    
                    <div class='dropdown-divider'> </div>
                    <a class='dropdown-item' href='./listaUsuarios.jsp'>Consulta Usuario</a>
                    
                </div>
            </li>
        </ul>
        <form class='form-inline my-2 my-lg-0 mr-auto' method='post' action='resultadoBusqueda'> <input class='form-control mr-2 mb-2 mt-2 shw-sm' type='search'
                placeholder='Buscar' aria-label='Search' style=' min-width: 200px;' name='BuscandoANemo'> <button
                class='btn btn-danger mr-2 mb-2 mt-2 shw-rojo-sm' style='width: 80 px;' type='submit'>Buscar</button>
        </form>
        <div id="log">

        </div>
    </div>
</nav>`;
	let footerString = "<footer class=' pt-5  rosadito_clarito_back'><div class='row'><div class=' col-sm-3 '></div><div class='col-sm-6 ' style='text-align: center;'><h5>Realizado por G01</h5><h6 class='mb-2'>Hecho con <span class='text-danger'>&#x2764</span> desde San Carlos</h6><h6 class='mb-3 text-dark'>Taller de Programación - TecnoInf - 2020</h6></div><div class='col-sm-3'></div></div></div></footer > ";
	document.getElementById("navbar-id").innerHTML = htmlContentToAppend;
	document.getElementById("footer-id").innerHTML = footerString;
	let htmlContentToAppendd = "";
	console.log("estes es: " + htmlContentToAppendd);
	if (localStorage.getItem('usu') !== undefined && localStorage.getItem('usu')) {
		htmlContentToAppendd = `
<div class="btn-group">
  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="min-width: 15rem;">
    <i class="fas fa-user-alt"><span>`+ localStorage.getItem('usu') + `</span></i>
  </button>
  <div class="dropdown-menu dropdown-menu-right">
	<button class="dropdown-item" type="button"><a  href="./consultaUser.jsp?nickname=`+ localStorage.getItem('usu') + `">Mis Datos</a></button>`;
	if(localStorage.getItem('tipo') !== undefined && localStorage.getItem('tipo')==="Estudiante"){
		htmlContentToAppendd=htmlContentToAppendd+`<div class='dropdown-divider'> </div><button class="dropdown-item" type="button"><a ' href='./listaResultadosInscripcion.jsp?nickname=`+ localStorage.getItem('usu')+`'>Lista de resultados<br> Inscripciones a Ediciones</a></button>`;
	}
	htmlContentToAppendd=htmlContentToAppendd+`<div class='dropdown-divider'> </div><button class="dropdown-item" type="button">  <a  href="./logout.jsp">Cerrar sesion</a></button>
	
  </div>
</div>
        `;
		
	} else {

		htmlContentToAppendd = `
    <button class='btn navbar-btn mr-2 mb-2 mt-2 btn-rosa-clarito btn-danger shw-rojo-sm' data-toggle='modal' data-target='#modal-login'> Iniciar Sesion</button> 
    <button class='btn navbar-btn mr-2 mb-2 mt-2 btn-danger shw-rojo-sm' data-toggle='modal' data-target='#modal-signup'>Registrarse</button> 

    `;
		cargarModals();
	}

    document.getElementById("log").innerHTML = htmlContentToAppendd;
    let lavariablesuprema ="";
    let lavar ="";
    let lav="";
    let variable="";
    let variablepapito="";
	let lavariable1 ="";

    if(localStorage.getItem('tipo') !== undefined && localStorage.getItem('tipo')==="Docente"){
        lavariablesuprema= ` <a class='dropdown-item' href='./altaCurso.jsp'>Crear curso</a> 
        <div class='dropdown-divider'></div>
        `;
        lavar=` <a class='dropdown-item' href='./altaEdicion.jsp'>Alta Edición</a>
        <div class='dropdown-divider'></div>
        
        <a class='dropdown-item' href='./selecionarEstudiantes.jsp'>Seleccionar estudiantes para una edicion</a>
        <div class='dropdown-divider'></div>
        <a class='dropdown-item' href='./listaEdicionAceptados.jsp'>Listar aceptados a una edicion</a>`;
        lav=`<a class='dropdown-item' href='./altaFormacion.jsp'>Alta Formacion</a>
                    
        <div class='dropdown-divider'> </div>
        <a class='dropdown-item' href='./agregarCursoFormacion.jsp'>Agregar cursos a Formacion</a>
        `;
		
		


    }else{
        if(localStorage.getItem('tipo') !== undefined && localStorage.getItem('tipo')==="Estudiante"){
            variable=`<a class='dropdown-item' href='./listaCursosParaInscripcion.jsp'>Inscripcion Edición</a>`;
            variablepapito = `<a class='dropdown-item' href='#'>Inscripcion a Formacion</a>`;
			lavariable1=`<div class='dropdown-divider'> </div><a class='dropdown-item' href='./listaResultadosInscripcion.jsp?nickname=`+ localStorage.getItem('usu')+`'>Lista de resultados de Inscripciones a Ediciones</a>`;

        }

    }
    document.getElementById("insced").innerHTML = variable;
    document.getElementById("esfor").innerHTML = variablepapito;
    document.getElementById("aled").innerHTML = lavar;
    document.getElementById("alfor").innerHTML = lav;
    document.getElementById("alcur").innerHTML = lavariablesuprema;
	document.getElementById("listaResultadosInscripciones").innerHTML = lavariable1;



}

function val_form(usr) {
	localStorage.clear();
	if (usr.trim() === "") {
		alert("Debes ingresar Usuario y contraseña");
		return false;
	}
	
}

function logout() {
	localStorage.clear();
	location.href = "./index.jsp";
}

function cargarModals() {
    let signup = `
        <div class="modal fade shadow" id="modal-signup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger">
                    <h4 class="modal-title " id="exampleModalLabel" style="color: white;">
                        Registrarse
                    </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form method="post" action="register">
                        <div class="form-row">
                            <h5 class="form-group col-sm-12" style="text-align: center; margin-bottom: 0px;">
                                Datos Personales
                            </h5>
                            <hr
                                style="width: 90%; color:lightgray; height: 0.5px; background-color:lightgray; border-radius: 50%;">
                            <div class="form-group col-sm-6">
                                <label for="nick_signup">Nickname <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" id="nick11" name="nick"
                                    placeholder="Ingrese su nickname (unico)" oninput="checkSignupInputs()" required>
								<div id="nik-div">
								</div>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="nombre">Nombre/es <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" name="nombre" placeholder="Ingrese su nombre"
                                    required>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="apellido">Apellidos <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" name="apellido"
                                    placeholder="Ingrese su apellido" required>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="mail">Email <span style="color: red;">*</span></label>
                                <input type="email" class="form-control" name="mail" id="maill"
                                    placeholder="Ingrese su email: ejemplo@gmail.com" required oninput="checkSignupInputs()">
								<div id="mail-div"></div>
                            </div>
                            <div class="form-group col-sm-4">
                                <label for="dia">Día<span style="color: red;">*</span></label>
                                <input type="number" class="form-control" name="dia" min="1" max="31">


                            </div>
                            <div class="form-group col-sm-4">
                                <label for="mes">Mes<span style="color: red;">*</span></label>
                                <input type="number" class="form-control" name="mes" min="1" max="12">


                            </div>
                            <div class="form-group col-sm-4">
                                <label for="anio">Año<span style="color: red;">*</span></label>
                                <input type="number" class="form-control" name="anio" min="1900" max="2010">

                            </div>

                            <div class="form-group col-sm-12">
                                <label for="passw">Contraseña<span style="color: red;">*</span></label>
                                <input type="password" class="form-control" name="pass_signup" id='passw'
                                    placeholder="Ingrese su Contraseña" required>
                            </div>
                            <div class="form-group col-sm-12 ">
                                <label for="passw2">Repite tu contraseña<span style="color: red;">*</span></label>
                                <input type="password" class="form-control" name="pass2_signup" id='passw2'
                                    placeholder="Ingresa devuelta la contraseña" oninput='checkSignupInputs()' required>
								<div id="pass-error">
								</div>
                            </div>
                            
                            <div class="form-group col-sm-12">
                                <div class="form-check col-sm-12">
                                    <input type="checkbox" class="form-check-input" name="check" id="check"
                                        onclick="esDoc(check.value)">
                                    <label class="form-check-label" for="check">¿Eres un docente? Si es asi
                                        selecciona
                                        esta opción.</label>
                                </div>
                            </div>




                            <div class=" form-group col-sm-12" id="instdoc">

                            </div>
                            <hr class="mb-4"
                                style="width: 90%; color:lightgray; height: 0.5px; background-color:lightgray; border-radius: 50%;">

                            <p style="color: red; font-size: 14px;">(*) Campos Obligatorios</p>
                            
                        </div>
                        <button type="submit" id="suubb" class="btn btn-danger  btn-block btn-lg shadow mb btn-rosa-clarito" >
                            Registrarme</button>
                        <button type="button" class="btn btn-sm btn-outline-danger btn-block"
                            data-dismiss="modal">Cancelar</button>
                    </form>

                </div>

            </div>
        </div>
    
    `;
	let login = `
    <div class="modal fade shadow" id="modal-login" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered  modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger ">
                    <h3 class="modal-title " id="exampleModalLabel" style="color: white;">
                        Iniciar Sesion
                    </h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="loggg">
                    <form method="post" action="loginCheck">
                        <div class="form-row">

                            <div class="form-group col-sm-12">
                                <label for="nick">Nickname</label>
                                <input type="text" class="form-control" id="kuni" name="nick"
                                    placeholder="Ingrese su nickname!" required>
                            </div>
                            <div class="form-group col-sm-12">
                                <label for="pass">Contraseña </label>
                                <input type="password" class="form-control" id="kunaguero" name="pass"
                                    placeholder="Ingrese su contraseña!" required>
                            </div>


                            <hr
                                style="width: 90%; color:lightgray; height: 0.5px; background-color:lightgray; border-radius: 50%;">


                        </div>
                        <button type="submit"
                            class="btn btn-danger btn-block button-color btn-lg shadow mb" >Entrar</button>
                        <button type="button" class="btn btn-sm btn-outline-danger btn-block " data-dismiss="modal"
                            data-toggle="modal" data-target="#modal-signup">Registrarme</button>
                        <button type="button" class="btn btn-sm btn-outline-danger btn-block"
                            data-dismiss="modal">Olvide mi contraseña</button>
                    </form>


                </div>

            </div>
        </div>
    </div>
    `;

	
	document.getElementById("login-id").innerHTML = login;
	document.getElementById("signup-id").innerHTML = signup;
}


