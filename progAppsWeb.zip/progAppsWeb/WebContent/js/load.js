function loadParts() {
    let htmlContentToAppend = `
    <nav class='navbar navbar-expand-lg navbar-light rosadito_back shw-sm'> <a class='navbar-brand ml-2' href='./index.jsp'>
        <strong>edEXT</strong> </a> <button class='navbar-toggler' type='button' data-toggle='collapse'
        data-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false'
        aria-label='Toggle navigation'> <span class='navbar-toggler-icon'> </span> </button>
    <div class='collapse navbar-collapse' id='navbarSupportedContent'>
        <ul class='navbar-nav mr-5'>

            <li class='nav-item dropdown'> <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown'
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Cursos</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown'> <a class='dropdown-item'
                        href='./altaCurso.jsp'>Crear curso</a> <a class='dropdown-item' href='#'> </a>
                    <div class='dropdown-divider'></div>
                    <a class='dropdown-item' href='./listaCurso.jsp'>Lista
                        Cursos</a>
                    <a class='dropdown-item' href='#'></a>
                    <div class='dropdown-divider'></div>
                    <a class='dropdown-item' href='./listaCurso.jsp'>Lista Cursos</a>
                    <a class='dropdown-item' href='#'></a>
                    <a class='dropdown-item' href='./listaCurso.jsp'>Consulta Cursos</a>
                    <a class='dropdown-item' href='#'></a>

                </div>
            </li>
            <li class='nav-item dropdown'> <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown2'
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Ediciones</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown2'>
                    <a class='dropdown-item' href='./consultaEdicion.jsp'>Consultar Ediciones</a>
                    <a class='dropdown-item' href='#'> </a>
                </div>
            </li>
            <li class='nav-item'> <a class='nav-link' href='#'>Formaciones</a> </li>
            <li class='nav-item'> <a class='nav-link ' href='#'> </a> </li>
            <li class='nav-item dropdown'>
                <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown1' role='button' data-toggle='dropdown'
                    aria-haspopup='true' aria-expanded='false'>Usuarios</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown1'>
                    <a class='dropdown-item' href='./listaUsuarios.jsp'>Lista Usuarios</a>
                    <a class='dropdown-item' href='#'> </a>
                    <div class='dropdown-divider'> </div>
                    <a class='dropdown-item' href='./listaUsuarios.jsp'>Consulta Usuario</a>
                    <a class='dropdown-item' href='#'> </a>
                </div>
            </li>
        </ul>
        <form class='form-inline my-2 my-lg-0 mr-auto'> <input class='form-control mr-2 mb-2 mt-2 shw-sm' type='search'
                placeholder='Buscar' aria-label='Search' style='width:50 vmin;'> <button
                class='btn btn-danger mr-2 mb-2 mt-2 shw-rojo-sm' style='width: 80 px;' type='submit'>Buscar</button>
        </form>
        <div id="log">

        </div>
    </div>
</nav>`;
    let footerString = "<footer class=' pt-5  rosadito_clarito_back'><div class='row'><div class=' col-sm-3 '></div><div class='col-sm-6 ' style='text-align: center;'><h5>Realizado por G01</h5><h6 class='mb-2'>Hecho con <span class='text-danger'>&#x2764</span> desde San Carlos</h6><h6 class='mb-3 text-dark'>Taller de Programación - TecnoInf - 2020</h6></div><div class='col-sm-3'></div></div></div></footer > ";
    document.getElementById("navbar-id").innerHTML = htmlContentToAppend;
    document.getElementById("footer-id").innerHTML = footerString;
}