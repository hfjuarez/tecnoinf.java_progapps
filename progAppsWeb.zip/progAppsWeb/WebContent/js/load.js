function loadParts() {
    let htmlContentToAppend = `
    <nav class='navbar navbar-expand-lg navbar-light rosadito_back shw-sm'> <a class='navbar-brand ml-2' href='./index.jsp'>
        <strong>edEXT</strong> </a> <button class='navbar-toggler' type='button' data-toggle='collapse'
        data-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false'
        aria-label='Toggle navigation'> <span class='navbar-toggler-icon'> </span> </button>
    <div class='collapse navbar-collapse' id='navbarSupportedContent'>
        <ul class='navbar-nav mr-5'>

            <li class='nav-item dropdown'> <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown'
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Cursos</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown'> 
					<a class='dropdown-item'
                        href='./altaCurso.jsp'>Crear curso</a> <a class='dropdown-item' href='#'> </a>
                    
					<div class='dropdown-divider'></div>
                    
					<a class='dropdown-item' href='./listaCurso.jsp'>Lista
                        Cursos</a>
                    <a class='dropdown-item' href='#'></a>
                
                    <div class='dropdown-divider'></div>
                
				    <a class='dropdown-item' href='./listaCurso.jsp'>Consulta Cursos</a>
                    <a class='dropdown-item' href='#'></a>

                </div>
            </li>
            <li class='nav-item dropdown'> <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown2'
                    role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Ediciones</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown2'>
                    <a class='dropdown-item' href='./consultaEdicion.jsp'>Consultar Ediciones</a>
                    <a class='dropdown-item' href='#'> </a>
                </div>
            </li>
            <li class='nav-item'> <a class='nav-link' href='#'>Formaciones</a> </li>
            <li class='nav-item'> <a class='nav-link ' href='#'> </a> </li>
            <li class='nav-item dropdown'>
                <a class='nav-link dropdown-toggle' href='#' id='navbarDropdown1' role='button' data-toggle='dropdown'
                    aria-haspopup='true' aria-expanded='false'>Usuarios</a>
                <div class='dropdown-menu' aria-labelledby='navbarDropdown1'>
                    <a class='dropdown-item' href='./listaUsuarios.jsp'>Lista Usuarios</a>
                    <a class='dropdown-item' href='#'> </a>
                    <div class='dropdown-divider'> </div>
                    <a class='dropdown-item' href='./listaUsuarios.jsp'>Consulta Usuario</a>
                    <a class='dropdown-item' href='#'> </a>
                </div>
            </li>
        </ul>
        <form class='form-inline my-2 my-lg-0 mr-auto'> <input class='form-control mr-2 mb-2 mt-2 shw-sm' type='search'
                placeholder='Buscar' aria-label='Search' style='width:50 vmin;'> <button
                class='btn btn-danger mr-2 mb-2 mt-2 shw-rojo-sm' style='width: 80 px;' type='submit'>Buscar</button>
        </form>
        <div id="log">

        </div>
    </div>
</nav>`;
    let footerString = "<footer class=' pt-5  rosadito_clarito_back'><div class='row'><div class=' col-sm-3 '></div><div class='col-sm-6 ' style='text-align: center;'><h5>Realizado por G01</h5><h6 class='mb-2'>Hecho con <span class='text-danger'>&#x2764</span> desde San Carlos</h6><h6 class='mb-3 text-dark'>Taller de Programación - TecnoInf - 2020</h6></div><div class='col-sm-3'></div></div></div></footer > ";
    document.getElementById("navbar-id").innerHTML = htmlContentToAppend;
    document.getElementById("footer-id").innerHTML = footerString;
    let htmlContentToAppendd = "";
    console.log("estes es: " + htmlContentToAppendd);
    if (localStorage.getItem('usu') !== undefined && localStorage.getItem('usu')) {
        htmlContentToAppendd = `
<div class="btn-group">
  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <i class="fas fa-user-alt"><span>`+ localStorage.getItem('usu') + `</span></i>
  </button>
  <div class="dropdown-menu dropdown-menu-right">
	<button class="dropdown-item" type="button"><a  href="./consultaUser.jsp?nickname=`+ localStorage.getItem('usu') + `">Mis Datos</a></button>
    <button class="dropdown-item" type="button">  <a  href="./logout.jsp">Cerrar sesion</a></button>
    
  
    
  </div>
</div>
    
        `;
        console.log("estes es: " + htmlContentToAppendd);
    } else {

        htmlContentToAppendd = `
    <button class='btn navbar-btn mr-2 mb-2 mt-2 btn-rosa-clarito btn-danger shw-rojo-sm' data-toggle='modal' data-target='#modal-login'> Iniciar Sesion</button> 
    <button class='btn navbar-btn mr-2 mb-2 mt-2 btn-danger shw-rojo-sm' data-toggle='modal' data-target='#modal-signup'>Registrarse</button> 

    `;
        cargarModals();
    }

    document.getElementById("log").innerHTML = htmlContentToAppendd;

}

function val_form(usr) {
    localStorage.clear();
    if (usr.trim() === "") {
        alert("Debes ingresar Usuario y contraseña");
        return false;
    }
    else {
        localStorage.setItem("usu", usr);

    }
}

function logout() {
    localStorage.clear();
    location.href = "./index.jsp";
}

function cargarModals() {
    let signup = `
    <div class="modal fade shadow" id="modal-signup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger">
                    <h4 class="modal-title " id="exampleModalLabel" style="color: white;">
                        Registrarse
                    </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form method="post" action="register" enctype="multipart/form-data">
                        <div class="form-row">
                            <h5 class="form-group col-sm-12" style="text-align: center; margin-bottom: 0px;">
                                Datos Personales
                            </h5>
                            <hr
                                style="width: 90%; color:lightgray; height: 0.5px; background-color:lightgray; border-radius: 50%;">
                            <div class="form-group col-sm-6">
                                <label for="nick_signup">Nickname <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" id="nick" name="nick"
                                    placeholder="Ingrese su nickname (unico)" required>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="nombre">Nombre/es <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" name="nombre" placeholder="Ingrese su nombre"
                                    required>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="apellido">Apellidos <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" name="apellido"
                                    placeholder="Ingrese su apellido" required>
                            </div>
                            <div class="form-group col-sm-6">
                                <label for="mail">Email <span style="color: red;">*</span></label>
                                <input type="email" class="form-control" name="mail"
                                    placeholder="Ingrese su email: ejemplo@gmail.com" required>
                            </div>
                            <div class="form-group col-sm-4">
                                <label for="dia">Día<span style="color: red;">*</span></label>
                                <input type="number" class="form-control" name="dia" min="1" max="31">


                            </div>
                            <div class="form-group col-sm-4">
                                <label for="mes">Mes<span style="color: red;">*</span></label>
                                <input type="number" class="form-control" name="mes" min="1" max="12">


                            </div>
                            <div class="form-group col-sm-4">
                                <label for="anio">Año<span style="color: red;">*</span></label>
                                <input type="number" class="form-control" name="anio" min="1900" max="2010">

                            </div>

                            <div class="form-group col-sm-12">
                                <label for="passw">Contraseña<span style="color: red;">*</span></label>
                                <input type="password" class="form-control" name="pass_signup"
                                    placeholder="Ingrese su Contraseña" required>
                            </div>
                            <div class="form-group col-sm-12 ">
                                <label for="passw2">Repite tu contraseña<span style="color: red;">*</span></label>
                                <input type="password" class="form-control" name="pass2_signup"
                                    placeholder="Ingresa devuelta la contraseña" required>
                            </div>
                            <div class="form-group col-sm-12">
                                <label for="img">Selecione una imagen <span style="color: red;">*</span></label>
                                <input type="file" class="form-control-file" id="img" name="imgUser"
                                    accept="image/png, image/jpg" required>
                            </div>
                            <div class="form-group col-sm-12">
                                <div class="form-check col-sm-12">
                                    <input type="checkbox" class="form-check-input" name="check" id="check"
                                        onclick="esDoc(check.value)">
                                    <label class="form-check-label" for="check">¿Eres un docente? Si es asi
                                        selecciona
                                        esta opción.</label>
                                </div>
                            </div>




                            <div class=" form-group col-sm-12" id="instdoc">

                            </div>
                            <hr class="mb-4"
                                style="width: 90%; color:lightgray; height: 0.5px; background-color:lightgray; border-radius: 50%;">

                            <p style="color: red; font-size: 14px;">(*) Campos Obligatorios</p>
                            <div class="form-group col-sm-12">
                                <div class="form-check" style="font-size: 14px;">
                                    <input class="form-check-input" type="checkbox" name="" id="aceptoTYC-PP">
                                    <Label for="aceptoTYC-PP" class="form-chack-label">Acepato los <a
                                            href="tyc.html">Terminos y Condiciones</a>, <a href="pp.html">Policas de
                                            Privacidad</a>.</Label>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-danger  btn-block btn-lg shadow mb btn-rosa-clarito">
                            Registrarme</button>
                        <button type="button" class="btn btn-sm btn-outline-danger btn-block"
                            data-dismiss="modal">Cancelar</button>
                    </form>

                </div>

            </div>
        </div>
    </div>
    `;
    let login = `
    <div class="modal fade shadow" id="modal-login" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered  modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header bg-danger ">
                    <h3 class="modal-title " id="exampleModalLabel" style="color: white;">
                        Iniciar Sesion
                    </h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="loggg">
                    <form method="post" action="loginCheck">
                        <div class="form-row">

                            <div class="form-group col-sm-12">
                                <label for="nick">Nickname</label>
                                <input type="text" class="form-control" id="kuni" name="nick"
                                    placeholder="Ingrese su nickname!" required>
                            </div>
                            <div class="form-group col-sm-12">
                                <label for="pass">Contraseña </label>
                                <input type="password" class="form-control" id="kunaguero" name="pass"
                                    placeholder="Ingrese su contraseña!" required>
                            </div>


                            <hr
                                style="width: 90%; color:lightgray; height: 0.5px; background-color:lightgray; border-radius: 50%;">


                        </div>
                        <button type="submit" value="login onclick=" val_form(kuni.value, kunaguero.value);"
                            class="btn btn-danger btn-block button-color btn-lg shadow mb" onclick="val_form(kuni.value)">Entrar</button>
                        <button type="button" class="btn btn-sm btn-outline-danger btn-block " data-dismiss="modal"
                            data-toggle="modal" data-target="#modal-signup">Registrarme</button>
                        <button type="button" class="btn btn-sm btn-outline-danger btn-block"
                            data-dismiss="modal">Olvide mi contraseña</button>
                    </form>


                </div>

            </div>
        </div>
    </div>
    `;

    document.getElementById("signup-id").innerHTML = signup;
    document.getElementById("login-id").innerHTML = login;
}