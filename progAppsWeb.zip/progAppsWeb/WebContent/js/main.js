
function obtenerValorParametro(sParametroNombre) {
var sPaginaURL = window.location.search.substring(1);
 var sURLVariables = sPaginaURL.split('&');
  for (var i = 0; i < sURLVariables.length; i++) {
    var sParametro = sURLVariables[i].split('=');
    if (sParametro[1] == sParametroNombre) {
      return sParametro[1];
    }
  }
 return null;
}

var valor = obtenerValorParametro('SHOW_ERROR_LOGIN');
if (valor=="SHOW_ERROR_LOGIN"){
	let joselito = "";
	joselito = '<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>USUARIO NO ENCONTRADO </strong>  La contraseña o usuario no son correctos!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button></div>';
	document.getElementById("SHOW").innerHTML = joselito;
}
    

	