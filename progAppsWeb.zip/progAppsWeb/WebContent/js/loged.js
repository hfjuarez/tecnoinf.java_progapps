function val_form(usr, pass) {
    localStorage.clear();
    if (usr.trim() === "" || pass.trim() === "") {
        alert("Debes ingresar Usuario y contraseña");
        return false;
    }
    else {
        localStorage.setItem("usuario", usr);
    }
}

let htmlContentToAppend = "";
varson = localStorage.getItem("usuario");
if (varson) {
    htmlContentToAppend = `
    <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-alt"><strong><span id="usrlog" ></span></strong></i>
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="my-profile.html">Mi Perfil</a>
            <a class="dropdown-item" id="salir" href="#" onclick=location.href="index.html";>Cerrar sesion</a>
          </div>
        </div>
`
    bool = false;
} else {
    htmlContentToAppend = `
    <form method="post" action="loginCheck">
    <div class="form-row">

        <div class="form-group col-sm-12">
            <label for="nick">Nickname</label>
            <input type="text" class="form-control" id="kuni" name="nick" placeholder="Ingrese su nickname!"
                required>
        </div>
        <div class="form-group col-sm-12">
            <label for="pass">Contraseña </label>
            <input type="password" class="form-control" id="kunaguero"name="pass"
                placeholder="Ingrese su contraseña!" required>
        </div>


        <hr
            style="width: 90%; color:lightgray; height: 0.5px; background-color:lightgray; border-radius: 50%;">


    </div>
    <button type="submit" value="login onclick="val_form(kuni.value, kunaguero.value);"
        class="btn btn-danger btn-block button-color btn-lg shadow mb">Entrar</button>
    <button type="button" class="btn btn-sm btn-outline-danger btn-block " data-dismiss="modal"
        data-toggle="modal" data-target="#modal-signup">Registrarme</button>
    <button type="button" class="btn btn-sm btn-outline-danger btn-block"
        data-dismiss="modal">Olvide mi contraseña</button>
</form>
`
}
document.getElementById("loggg").innerHTML = htmlContentToAppend;
document.getElementById("usrlog").innerHTML = varson;
