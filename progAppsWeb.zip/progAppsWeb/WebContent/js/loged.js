function val_form(usr){
    localStorage.clear();
    if(usr.trim()===""){
        alert("Debes ingresar Usuario y contraseña");
        return false;
    }
    else{
        localStorage.setItem("usu",usr);
    }
}
let htmlContentToAppend = "";
if(localStorage.getItem('usu') !== undefined && localStorage.getItem('usu')){
    htmlContentToAppend = `
    <div class="dropdown">
    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-user-alt"><strong><span>`+localStorage.getItem('usu')+`</span></strong></i>
    </button>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item" href="cart.html">Mi carrito</a>
      <a class="dropdown-item" href="my-profile.html">Mi Perfil</a>
      <a class="dropdown-item" id="salir" href="#" onclick=location.href="index.html";>Cerrar sesion</a>
    </div>
  </div>
        `
}else{
    htmlContentToAppend = `
    <button class='btn navbar-btn mr-2 mb-2 mt-2 btn-rosa-clarito btn-danger shw-rojo-sm' data-toggle='modal' data-target='#modal-login'> Iniciar Sesion</button> 
    <button class='btn navbar-btn mr-2 mb-2 mt-2 btn-danger shw-rojo-sm' data-toggle='modal' data-target='#modal-signup'>Registrarse</button> 

    `
}

document.getElementById("log").innerHTML = htmlContentToAppend;