
function consultaUser(nick) {
	console.log('antes ');

	if (nick !== localStorage.getItem("usu")) {

		document.getElementById("op-modificarUser").innerHTML = '';

	}

	console.log('bueno');
	var l = document.getElementById('loader-id');
	l.style.visibility = 'hidden';
	l.style.opacity = '0';
	var l2 = document.getElementById('buenardo-id');
	l2.style.visibility = 'hidden';
	l2.style.opacity = '0';
}