

import java.io.IOException;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import API.BizcochoEnARG;
import API.IWeb;
import API.datatypes.DTCurso;

/**
 * Servlet implementation class altaEdicion
 */
@WebServlet("/altaEdicion")
public class altaEdicion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public altaEdicion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String instituto = request.getParameter("instituto");
		String curso = request.getParameter("curso");
		String nom = request.getParameter("nombreEdicion");
		String fechIn = request.getParameter("fechaInicio");
		String fechFin = request.getParameter("fechaFin");
		String cupos = request.getParameter("cantidadCupos");
		response.getWriter().println(instituto + curso+nom + fechIn + fechFin+cupos);
		IWeb webbb = new BizcochoEnARG().getWebInterface();
		//webbb.crearEdicion(nom, curso,fechaInicio , fechaFin, cupo, fechaAhora, null, null);
		//public String crearEdicion(String nombreEdicion, String curso, Date FechaInicio, Date FechaFin, int Cupo,Date fechaAlta, List<String> docentes, File imagen);
		if(request.getParameter("instituto")!=null) {
			response.sendRedirect("./altaEdicion.jsp?insti="+request.getParameter("instituto"));
		}else {
			response.getWriter().print("vacio");
		}
	}

}
