
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import API.BizcochoEnARG;
import API.IWeb;
import API.datatypes.DTCurso;

/**
 * Servlet implementation class altaEdicion
 */
@WebServlet("/altaEdicion")
public class altaEdicion extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public altaEdicion() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		String curso = request.getParameter("curso");
		String nom = request.getParameter("nombreEdicion");
		String fechIn = request.getParameter("fechaInicio");
		String fechFin = request.getParameter("fechaFin");
		int cupos = Integer.parseInt(request.getParameter("cantidadCupos"));
		Date d1 = Date.valueOf(fechIn);
		Date d2 = Date.valueOf(fechFin);
		long millis = System.currentTimeMillis();
		Date d3 = new Date(millis);
		String docs[] = request.getParameterValues("docentes");
		List<String> doc = new ArrayList<String>();
		for (int i = 0; i < docs.length; i++) {
			doc.add(docs[i]);
		}
		File img = null;

		response.getWriter().println(curso + nom + fechIn + fechFin + cupos);
		IWeb webbb = new BizcochoEnARG().getWebInterface();
		String ret = webbb.crearEdicion(nom, curso, d1, d2, cupos, d3, doc, img);
		if (ret.isEmpty()) {
			response.sendRedirect("./upImg.jsp?filename=" + nom + "&foldername=ediciones"
					+ "&linkTo=success.jsp&linkToParameter=index.jsp&textOut=Creada la edicion " + nom
					+ "<br>Del curso " + curso);
		} else {
			response.sendRedirect(
					"./error.jsp?linkTo=index.jsp&textOut=Ha sucedido un <strong>error</strong> al crear la edicion!&error="
							+ ret);
		}
	}

}