

import java.io.File;
import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import API.BizcochoEnARG;
import API.IWeb;


/**
 * Servlet implementation class modificarUser
 */
@WebServlet("/modificarUser")
public class modificarUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public modificarUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);

	String nickname = request.getParameter("nick");
	String nom = request.getParameter("nombre");
	String ape = request.getParameter("apellido");
	String d = request.getParameter("dia");
	String m = request.getParameter("mes");
	String a = request.getParameter("anio");
	String datebro = a + "-" + m + "-" + d;
    Date dateee = Date.valueOf(datebro);
	File imagen = null;
	IWeb webb = new BizcochoEnARG().getWebInterface();
		
	String ret= webb.ModificarUsuario(nickname, nom, ape, dateee, imagen);

	if (ret.isEmpty()) {
			response.sendRedirect("./upImg.jsp?filename="+nickname+"&foldername=usuarios"+"&linkTo=success.jsp&linkToParameter=index.jsp&textOut=Modificado!<br><strong>"+nom+" "+ape+"</strong> ("+nickname+")");
		} else {
			response.sendRedirect(
					"./error.jsp?linkTo=index.jsp&textOut=Ha sucedido un <strong>error</strong> al modificar el usuario!&error="
							+ ret);
		}
	}

	

}
