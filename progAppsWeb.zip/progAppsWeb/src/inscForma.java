
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import API.*;
import java.sql.Date;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import java.util.*;
import java.sql.Date;

/**
 * Servlet implementation class inscEdicion
 */
@WebServlet("/inscForma")
public class inscForma extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public inscForma() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		IWeb webb = new BizcochoEnARG().getWebInterface();
		Calendar c = Calendar.getInstance();
		String dia = Integer.toString(c.get(Calendar.DATE));
		String mes = Integer.toString(c.get(Calendar.MONTH));
		String annio = Integer.toString(c.get(Calendar.YEAR));
		Date fechaActual = Date.valueOf(annio + "-" + mes + "-" + dia);
		String forsita=request.getParameter("formulaxd");
		String n =request.getParameter("nick");
		String ret = webb.regInscDeUsrEnFormacion(n,forsita , fechaActual);
		if(ret.isEmpty()) {
			response.sendRedirect("success.jsp?linkTo=listaFormacionParaInscripcion.jsp&textOut=Felicitaciones!<br>Te has inscripto a: <strong>"+ forsita+"<strong>.&success=El usuario con nickname: <strong>"+n+"</strong> ha realizado la inscripcion con exito!");
		}
		else {
			response.sendRedirect(
					"./error.jsp?linkTo=index.jsp&textOut=Ha sucedido un <strong>error</strong> al inscribirte a la Formaci�n!&error="
							+ ret);
		}
	}

}
