import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.util.*;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import API.*;
/**
 * Servlet implementation class altaCur
 */
@WebServlet("/agregarCurFor")
public class agregarCurFor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public agregarCurFor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stu

		
		String nomb = request.getParameter("formacion");
		String[] curs = request.getParameterValues("cursitos");
		List<String> cursed= new ArrayList<String>();
		for(int a = 0; a<curs.length;a++)
		{
			cursed.add(curs[a]);
		}
		IWeb webb = new BizcochoEnARG().getWebInterface();
		String ret= webb.AgregoCurEnForm(nomb, cursed);
		
		if(ret.isEmpty()) {
			response.sendRedirect("./agregarCursoFormacion.jsp?buenazo=SE_CREO");
		}
		else {
			response.sendRedirect(
					"./error.jsp?linkTo=index.jsp&textOut=Ha sucedido un <strong>error</strong> al agregar el curso a la formacion!&error="
							+ ret);
		}
		
		
	}

}