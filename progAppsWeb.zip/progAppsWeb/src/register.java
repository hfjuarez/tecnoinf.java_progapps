
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import API.*;
import java.sql.Date;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import java.util.*;

/**
 * Servlet implementation class register
 */
@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public register() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// doGet(request, response);
		String nickname = request.getParameter("nick");
		String nomb = request.getParameter("nombre");
		String apelli = request.getParameter("apellido");
		String email = request.getParameter("mail");
		String day = request.getParameter("dia");

		String mont = request.getParameter("mes");
		String yiar = request.getParameter("anio");
		System.out.println(day + "-" + mont + "-" + yiar);
		System.out.println(nickname);
		System.out.println(nomb);
		System.out.println(apelli);
		String datinho = yiar + "-" + mont + "-" + day;
		System.out.println(datinho);
		Date retorninho = Date.valueOf(datinho);
		String password1 = request.getParameter("pass_signup");
		String password2 = request.getParameter("pass2_signup");
		System.out.println("carlos: " + request.getParameter("check"));
		File img = null;

		IWeb webb = new BizcochoEnARG().getWebInterface();
		String ret = "";
		String est_doc = "";
		if (request.getParameter("check") != null) {
			if (request.getParameter("check").equals("on")) {
				String instigay = request.getParameter("ins");
				// (String nickname, String nombre, String apellido, String mail, Date fechaNac,
				// String instituto, File imagen, String passw, String passw2)
				ret = webb.crearUsuarioDocente(nickname, nomb, apelli, email, retorninho, instigay, img, password1,
						password2);
				est_doc = "Profesor";
			}
		} else {
			// (String nickname, String nombre, String apellido, String mail, Date fechaNac,
			// File imagen, String passw, String passw2)

			ret = webb.crearUsuarioEstudiante(nickname, nomb, apelli, email, retorninho, img, password1, password2);
			est_doc = "Estudiante";
		}
		if (ret.isEmpty()) {
			response.sendRedirect("./upImg.jsp?filename="+nickname+"&foldername=usuarios"+"&linkTo=success.jsp&linkToParameter=index.jsp&textOut=Bienvenido!<br>"+est_doc+": <strong>"+nomb+" "+apelli+"</strong> ("+nickname+")");
		} else {
			response.sendRedirect(
					"./error.jsp?linkTo=index.jsp&textOut=Ha sucedido un <strong>error</strong> al registrar el usuario!&error="
							+ ret);
		}

	}

}
