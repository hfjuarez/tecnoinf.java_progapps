
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import API.*;
import java.sql.Date;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import java.util.*;
import java.sql.Date;

/**
 * Servlet implementation class certi
 */
@WebServlet("/certi")
public class certi extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public certi() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		IWeb webb = new BizcochoEnARG().getWebInterface();
		String form = request.getParameter("formacion");
		String estu = request.getParameter("nickname");

		Boolean ret = webb.obtenerCertificado(form, estu);
		if (ret) {
			response.sendRedirect(
					"./error.jsp?linkTo=index.jsp&textOut=Ha sucedido un <strong>error</strong> al certificar, Usted no posee la nota necesaria");
		} else {
			response.sendRedirect(
					"./error.jsp?linkTo=index.jsp&textOut=Ha sucedido un <strong>error</strong> al certificar, Usted no posee la nota necesaria");
		}

	}

}
