

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.util.*;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import API.*;
/**
 * Servlet implementation class altaCur
 */
@WebServlet("/altaCur")
public class altaCur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public altaCur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stu

		String inst = request.getParameter("instituto");
		String nomb = request.getParameter("nombreCurso");
		int Duracc = Integer.parseInt(request.getParameter("duracionSem"));
		int horas = Integer.parseInt(request.getParameter("cantidadHoras"));
		int merca = Integer.parseInt(request.getParameter("cantidadCreditos"));
		String descc = request.getParameter("descCurso");
		String urlcurso = request.getParameter("URL");
		System.out.println("el nombre es: "+ nomb);
		File img=null;
		List<String> previi=new ArrayList<String>();
		List<String> categorias=new ArrayList<String>();


		Calendar c = Calendar.getInstance();
		String dia = Integer.toString(c.get(Calendar.DATE));
		String mes = Integer.toString(c.get(Calendar.MONTH));
		String annio = Integer.toString(c.get(Calendar.YEAR));
		Date ahora = Date.valueOf(annio + "-" + mes + "-" + dia);
		IWeb webb = new BizcochoEnARG().getWebInterface();
		String ret= webb.crearCurso(nomb, descc, Duracc, horas, merca, urlcurso,
				ahora, previi, inst, categorias, img);
		if(ret.isEmpty()) {
			response.sendRedirect("./altaCurso.jsp?buenazo=SE_CREO");
		}
		else {
			response.sendRedirect("./altaCurso.jsp?malardo="+ret);
		}
		
		
	}

}
