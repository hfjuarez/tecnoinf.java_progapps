

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.util.*;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import API.*;
/**
 * Servlet implementation class altaCur
 */
@WebServlet("/altaCur")
public class altaCur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public altaCur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stu

		String inst = request.getParameter("instituto");
		String nomb = request.getParameter("nombreCurso");
		int Duracc = Integer.parseInt(request.getParameter("duracionSem"));
		int horas = Integer.parseInt(request.getParameter("cantidadHoras"));
		int merca = Integer.parseInt(request.getParameter("cantidadCreditos"));
		String descc = request.getParameter("descCurso");
		String urlcurso = request.getParameter("URL");
		System.out.println("EL NOMBRE EEEEEEEEEEEEEEEEEEEEEEES: "+ nomb);
		File img=null;

		String[] previs = request.getParameterValues("previas");
		String[] categos = request.getParameterValues("cate");

		List<String> previi= new ArrayList<String>();
		List<String> categoriasc=new ArrayList<String>();

		for(int a = 0; a<previs.length;a++)
		{
			previi.add(previs[a]);
		}
		for(int a = 0; a<categos.length;a++)
		{
			categoriasc.add(categos[a]);
		}

		Calendar c = Calendar.getInstance();
		String dia = Integer.toString(c.get(Calendar.DATE));
		String mes = Integer.toString(c.get(Calendar.MONTH));
		String annio = Integer.toString(c.get(Calendar.YEAR));
		Date ahora = Date.valueOf(annio + "-" + mes + "-" + dia);
		IWeb webb = new BizcochoEnARG().getWebInterface();
		String ret= webb.crearCurso(nomb, descc, Duracc, horas, merca, urlcurso,
				ahora, previi, inst, categoriasc, img);
		if(ret.isEmpty()) {
			response.sendRedirect("./upImg.jsp?filename="+nomb+"&foldername=cursos"+"&linkTo=success.jsp&linkToParameter=altaCurso.jsp&textOut=Se ha creado el curso: <strong>"+nomb+"</strong> con exito!");
		}
		else {
			response.sendRedirect(
					"./error.jsp?linkTo=altaCurso.jsp&textOut=Ha sucedido un <strong>error</strong> al crear el curso!&error="
							+ ret);
		}
		
		
	}

}