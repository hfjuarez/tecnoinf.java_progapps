import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.util.*;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import API.*;
/**
 * Servlet implementation class altaCur
 */
@WebServlet("/altaFor")
public class altaFor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public altaFor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stu

		
		String nomb = request.getParameter("nombrefor");
		String dI = request.getParameter("diaI");
		String mI = request.getParameter("mesI");
		String aI = request.getParameter("anioI");
		String dF = request.getParameter("diaF");
		String mF = request.getParameter("mesF");
		String aF = request.getParameter("anioF");
		
		String dateIbro = aI + "-" + mI + "-" + dI;
        Date dateI = Date.valueOf(dateIbro);
        
        String dateFbro = aF + "-" + mF + "-" + dF;
        Date dateF = Date.valueOf(dateFbro);
		
		String descc = request.getParameter("descCurso");
		File img=null;
		

		Calendar c = Calendar.getInstance();
		String dia = Integer.toString(c.get(Calendar.DATE));
		String mes = Integer.toString(c.get(Calendar.MONTH));
		String annio = Integer.toString(c.get(Calendar.YEAR));
		Date ahora = Date.valueOf(annio + "-" + mes + "-" + dia);
		IWeb webb = new BizcochoEnARG().getWebInterface();
		
		String ret= webb.crearFormacion(nomb, descc, dateI, dateF, ahora,
				img);
		
		if(ret.isEmpty()) {
			
			response.sendRedirect("./upImg.jsp?filename="+nomb+"&foldername=formaciones"+"&linkTo=success.jsp&linkToParameter=altaFormacion.jsp&textOut=Se ha creado el Programa Formacion <strong>"+ nomb+ "</strong> con exito!");
		}
		else {
			response.sendRedirect(
					"./error.jsp?linkTo=index.jsp&textOut=Ha sucedido un <strong>error</strong> al crear la formacion!&error="
							+ ret);
		}
		
		
	}

}